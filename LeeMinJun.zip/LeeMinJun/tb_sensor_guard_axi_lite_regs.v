`timescale 1ns / 1ps

//////////////////////////////////////////////////////////////////////////////////
// tb_sensor_guard_axi_lite_regs
//
// Self-checking testbench for sensor_guard_axi_lite_regs.v
// Verilog-2005
//////////////////////////////////////////////////////////////////////////////////

module tb_sensor_guard_axi_lite_regs;

    localparam integer C_S_AXI_ADDR_WIDTH = 7;
    localparam integer C_S_AXI_DATA_WIDTH = 32;

    localparam [1:0] AXI_RESP_OKAY   = 2'b00;
    localparam [1:0] AXI_RESP_SLVERR = 2'b10;

    localparam [6:0] ADDR_CONTROL      = 7'h00;
    localparam [6:0] ADDR_THRESHOLD    = 7'h04;
    localparam [6:0] ADDR_MAX_DELTA    = 7'h08;
    localparam [6:0] ADDR_STALE_LIMIT  = 7'h0C;
    localparam [6:0] ADDR_CURRENT_ADC  = 7'h10;
    localparam [6:0] ADDR_MIN_MAX      = 7'h14;
    localparam [6:0] ADDR_STATUS       = 7'h18;
    localparam [6:0] ADDR_SAMPLE_COUNT = 7'h1C;
    localparam [6:0] ADDR_ALARM_COUNT  = 7'h20;
    localparam [6:0] ADDR_LAST_DELTA   = 7'h24;
    localparam [6:0] ADDR_IP_VERSION   = 7'h28;

    reg clk;
    reg reset_p;

    reg  [6:0]  s_axil_awaddr;
    reg         s_axil_awvalid;
    wire        s_axil_awready;

    reg  [31:0] s_axil_wdata;
    reg  [3:0]  s_axil_wstrb;
    reg         s_axil_wvalid;
    wire        s_axil_wready;

    wire [1:0]  s_axil_bresp;
    wire        s_axil_bvalid;
    reg         s_axil_bready;

    reg  [6:0]  s_axil_araddr;
    reg         s_axil_arvalid;
    wire        s_axil_arready;

    wire [31:0] s_axil_rdata;
    wire [1:0]  s_axil_rresp;
    wire        s_axil_rvalid;
    reg         s_axil_rready;

    wire        enable;
    wire        clear_pulse;
    wire [11:0] low_threshold;
    wire [11:0] high_threshold;
    wire [11:0] max_delta;
    wire [31:0] stale_limit_cycles;

    reg  [11:0] current_adc;
    reg  [11:0] min_adc;
    reg  [11:0] max_adc;
    reg  [11:0] last_delta;

    reg         data_seen;
    reg         display_valid;
    reg         under_alarm;
    reg         over_alarm;
    reg         delta_alarm;
    reg         stale_alarm;
    reg         sensor_alarm;

    reg  [31:0] sample_count;
    reg  [31:0] alarm_count;

    integer check_count;
    integer failure_count;

    sensor_guard_axi_lite_regs #(
        .C_S_AXI_ADDR_WIDTH     (C_S_AXI_ADDR_WIDTH),
        .C_S_AXI_DATA_WIDTH     (C_S_AXI_DATA_WIDTH),
        .LOW_THRESHOLD_DEFAULT  (410),
        .HIGH_THRESHOLD_DEFAULT (3685),
        .MAX_DELTA_DEFAULT      (512),
        .STALE_LIMIT_DEFAULT    (50_000_000)
    ) dut (
        .clk                 (clk),
        .reset_p             (reset_p),

        .s_axil_awaddr       (s_axil_awaddr),
        .s_axil_awvalid      (s_axil_awvalid),
        .s_axil_awready      (s_axil_awready),

        .s_axil_wdata        (s_axil_wdata),
        .s_axil_wstrb        (s_axil_wstrb),
        .s_axil_wvalid       (s_axil_wvalid),
        .s_axil_wready       (s_axil_wready),

        .s_axil_bresp        (s_axil_bresp),
        .s_axil_bvalid       (s_axil_bvalid),
        .s_axil_bready       (s_axil_bready),

        .s_axil_araddr       (s_axil_araddr),
        .s_axil_arvalid      (s_axil_arvalid),
        .s_axil_arready      (s_axil_arready),

        .s_axil_rdata        (s_axil_rdata),
        .s_axil_rresp        (s_axil_rresp),
        .s_axil_rvalid       (s_axil_rvalid),
        .s_axil_rready       (s_axil_rready),

        .enable              (enable),
        .clear_pulse         (clear_pulse),
        .low_threshold       (low_threshold),
        .high_threshold      (high_threshold),
        .max_delta           (max_delta),
        .stale_limit_cycles  (stale_limit_cycles),

        .current_adc         (current_adc),
        .min_adc             (min_adc),
        .max_adc             (max_adc),
        .last_delta          (last_delta),

        .data_seen           (data_seen),
        .display_valid       (display_valid),
        .under_alarm         (under_alarm),
        .over_alarm          (over_alarm),
        .delta_alarm         (delta_alarm),
        .stale_alarm         (stale_alarm),
        .sensor_alarm        (sensor_alarm),

        .sample_count        (sample_count),
        .alarm_count         (alarm_count)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        #100000;
        $display("[TIMEOUT] Testbench did not finish.");
        $finish;
    end

    task check1;
        input [8*96-1:0] label_text;
        input actual_value;
        input expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=%b expected=%b @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=%b",
                         label_text, actual_value);
            end
        end
    endtask

    task check2;
        input [8*96-1:0] label_text;
        input [1:0] actual_value;
        input [1:0] expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=%b expected=%b @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=%b",
                         label_text, actual_value);
            end
        end
    endtask

    task check32;
        input [8*96-1:0] label_text;
        input [31:0] actual_value;
        input [31:0] expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=0x%08h expected=0x%08h @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=0x%08h",
                         label_text, actual_value);
            end
        end
    endtask

    task axi_write_same;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input [1:0]  expected_response;
        reg aw_done;
        reg w_done;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;
            s_axil_wdata   = data_value;
            s_axil_wstrb   = strobe_value;
            s_axil_wvalid  = 1'b1;

            aw_done = 1'b0;
            w_done  = 1'b0;

            while (!(aw_done && w_done)) begin
                @(posedge clk);

                if (s_axil_awvalid && s_axil_awready)
                    aw_done = 1'b1;

                if (s_axil_wvalid && s_axil_wready)
                    w_done = 1'b1;

                @(negedge clk);

                if (aw_done)
                    s_axil_awvalid = 1'b0;

                if (w_done)
                    s_axil_wvalid = 1'b0;
            end

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("AXI Write BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("AXI Write BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_write_aw_first;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input integer delay_cycles;
        input [1:0]  expected_response;
        integer index;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;

            while (!s_axil_awready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_awvalid = 1'b0;

            check1("AW-first no early BVALID", s_axil_bvalid, 1'b0);

            for (index = 0; index < delay_cycles; index = index + 1) begin
                @(posedge clk);
                #1;
                check1("AW-first waits for W", s_axil_bvalid, 1'b0);
            end

            @(negedge clk);
            s_axil_wdata  = data_value;
            s_axil_wstrb  = strobe_value;
            s_axil_wvalid = 1'b1;

            while (!s_axil_wready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_wvalid = 1'b0;

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("AW-first BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("AW-first BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_write_w_first;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input integer delay_cycles;
        input [1:0]  expected_response;
        integer index;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_wdata  = data_value;
            s_axil_wstrb  = strobe_value;
            s_axil_wvalid = 1'b1;

            while (!s_axil_wready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_wvalid = 1'b0;

            check1("W-first no early BVALID", s_axil_bvalid, 1'b0);

            for (index = 0; index < delay_cycles; index = index + 1) begin
                @(posedge clk);
                #1;
                check1("W-first waits for AW", s_axil_bvalid, 1'b0);
            end

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;

            while (!s_axil_awready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_awvalid = 1'b0;

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("W-first BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("W-first BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_read_check;
        input [6:0]  address;
        input [31:0] expected_data;
        input [1:0]  expected_response;
        begin
            s_axil_rready = 1'b1;

            @(negedge clk);
            s_axil_araddr  = address;
            s_axil_arvalid = 1'b1;

            while (!s_axil_arready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_arvalid = 1'b0;

            while (!s_axil_rvalid)
                @(negedge clk);

            check2("AXI Read RRESP", s_axil_rresp, expected_response);
            check32("AXI Read RDATA", s_axil_rdata, expected_data);

            @(posedge clk);
            #1;
            check1("AXI Read RVALID released", s_axil_rvalid, 1'b0);
        end
    endtask

    initial begin
        check_count   = 0;
        failure_count = 0;

        reset_p = 1'b0;

        s_axil_awaddr  = 7'd0;
        s_axil_awvalid = 1'b0;
        s_axil_wdata   = 32'd0;
        s_axil_wstrb   = 4'd0;
        s_axil_wvalid  = 1'b0;
        s_axil_bready  = 1'b1;

        s_axil_araddr  = 7'd0;
        s_axil_arvalid = 1'b0;
        s_axil_rready  = 1'b1;

        current_adc   = 12'd0;
        min_adc       = 12'd0;
        max_adc       = 12'd0;
        last_delta    = 12'd0;

        data_seen     = 1'b0;
        display_valid = 1'b0;
        under_alarm   = 1'b0;
        over_alarm    = 1'b0;
        delta_alarm   = 1'b0;
        stale_alarm   = 1'b0;
        sensor_alarm  = 1'b0;

        sample_count  = 32'd0;
        alarm_count   = 32'd0;

        $display("\n============================================================");
        $display("TEST 1: Reset Defaults and Complete Register Map");
        $display("============================================================");

        #2;
        reset_p = 1'b1;
        #1;

        check1 ("Reset enable", enable, 1'b0);
        check1 ("Reset clear_pulse", clear_pulse, 1'b0);
        check32("Reset low_threshold", {20'd0, low_threshold}, 32'd410);
        check32("Reset high_threshold", {20'd0, high_threshold}, 32'd3685);
        check32("Reset max_delta", {20'd0, max_delta}, 32'd512);
        check32("Reset stale_limit", stale_limit_cycles, 32'd50_000_000);
        check1 ("Reset BVALID", s_axil_bvalid, 1'b0);
        check1 ("Reset RVALID", s_axil_rvalid, 1'b0);

        #9;
        reset_p = 1'b0;
        @(posedge clk);
        #1;

        check1("AWREADY after reset", s_axil_awready, 1'b1);
        check1("WREADY after reset", s_axil_wready, 1'b1);
        check1("ARREADY after reset", s_axil_arready, 1'b1);

        axi_read_check(ADDR_CONTROL,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD,    32'h0E65_019A, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,    32'h0000_0200, AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT,  32'h02FA_F080, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,       32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("TEST 2: CONTROL ENABLE and CLEAR W1P");
        $display("============================================================");

        axi_write_same(ADDR_CONTROL, 32'h0000_0001, 4'b0001,
                       AXI_RESP_OKAY);

        check1("CONTROL enable set", enable, 1'b1);
        check1("CLEAR remains low", clear_pulse, 1'b0);
        axi_read_check(ADDR_CONTROL, 32'h0000_0001, AXI_RESP_OKAY);

        s_axil_bready = 1'b0;

        @(negedge clk);
        s_axil_awaddr  = ADDR_CONTROL;
        s_axil_awvalid = 1'b1;
        s_axil_wdata   = 32'h0000_0003;
        s_axil_wstrb   = 4'b0001;
        s_axil_wvalid  = 1'b1;

        @(posedge clk);
        #1;

        check1("CLEAR pulse asserted", clear_pulse, 1'b1);
        check1("ENABLE preserved during CLEAR", enable, 1'b1);
        check1("CLEAR produced BVALID", s_axil_bvalid, 1'b1);
        check2("CLEAR BRESP", s_axil_bresp, AXI_RESP_OKAY);

        @(negedge clk);
        s_axil_awvalid = 1'b0;
        s_axil_wvalid  = 1'b0;

        @(posedge clk);
        #1;
        check1("CLEAR pulse exactly one clock", clear_pulse, 1'b0);
        check1("BVALID held while BREADY low", s_axil_bvalid, 1'b1);

        @(negedge clk);
        s_axil_bready = 1'b1;

        @(posedge clk);
        #1;
        check1("CLEAR response accepted", s_axil_bvalid, 1'b0);

        axi_read_check(ADDR_CONTROL, 32'h0000_0001, AXI_RESP_OKAY);

        axi_write_same(ADDR_CONTROL, 32'h0000_0002, 4'b0000,
                       AXI_RESP_OKAY);
        check1("Zero WSTRB preserves enable", enable, 1'b1);
        check1("Zero WSTRB does not clear", clear_pulse, 1'b0);

        $display("\n============================================================");
        $display("TEST 3: AW/W Independent Arrival");
        $display("============================================================");

        axi_write_aw_first(ADDR_THRESHOLD, 32'h0DAC_012C, 4'b1111,
                           2, AXI_RESP_OKAY);
        check32("AW-first low_threshold", {20'd0, low_threshold}, 32'd300);
        check32("AW-first high_threshold", {20'd0, high_threshold}, 32'd3500);
        axi_read_check(ADDR_THRESHOLD, 32'h0DAC_012C, AXI_RESP_OKAY);

        axi_write_w_first(ADDR_MAX_DELTA, 32'd777, 4'b1111,
                          2, AXI_RESP_OKAY);
        check32("W-first max_delta", {20'd0, max_delta}, 32'd777);
        axi_read_check(ADDR_MAX_DELTA, 32'd777, AXI_RESP_OKAY);

        axi_write_same(ADDR_STALE_LIMIT, 32'h1234_5678, 4'b1111,
                       AXI_RESP_OKAY);
        check32("STALE_LIMIT full write", stale_limit_cycles,
                32'h1234_5678);
        axi_read_check(ADDR_STALE_LIMIT, 32'h1234_5678, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("TEST 4: WSTRB Partial Write");
        $display("============================================================");

        axi_write_same(ADDR_THRESHOLD, 32'h0000_00AA, 4'b0001,
                       AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD, 32'h0DAC_01AA, AXI_RESP_OKAY);

        axi_write_same(ADDR_THRESHOLD, 32'h0000_0B00, 4'b0010,
                       AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD, 32'h0DAC_0BAA, AXI_RESP_OKAY);

        axi_write_same(ADDR_THRESHOLD, 32'h00CC_0000, 4'b0100,
                       AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD, 32'h0DCC_0BAA, AXI_RESP_OKAY);

        axi_write_same(ADDR_THRESHOLD, 32'h0A00_0000, 4'b1000,
                       AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD, 32'h0ACC_0BAA, AXI_RESP_OKAY);

        axi_write_same(ADDR_STALE_LIMIT, 32'hAA00_BB00, 4'b1010,
                       AXI_RESP_OKAY);
        check32("STALE_LIMIT partial WSTRB", stale_limit_cycles,
                32'hAA34_BB78);
        axi_read_check(ADDR_STALE_LIMIT, 32'hAA34_BB78, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("TEST 5: Read-only Register Map and STATUS Bits");
        $display("============================================================");

        current_adc   = 12'hABC;
        min_adc       = 12'h111;
        max_adc       = 12'hEEE;
        last_delta    = 12'h234;

        data_seen     = 1'b1;
        display_valid = 1'b1;
        under_alarm   = 1'b1;
        over_alarm    = 1'b0;
        delta_alarm   = 1'b1;
        stale_alarm   = 1'b1;
        sensor_alarm  = 1'b1;

        sample_count  = 32'h1234_5678;
        alarm_count   = 32'hABCD_EF01;

        // STATUS = 0xEF:
        // sensor, stale, delta, over=0, under, display, data_seen, enable
        axi_read_check(ADDR_CURRENT_ADC,  32'h0000_0ABC, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0EEE_0111, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,       32'h0000_00EF, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'h1234_5678, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'hABCD_EF01, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'h0000_0234, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        data_seen     = 1'b0;
        display_valid = 1'b0;
        under_alarm   = 1'b0;
        over_alarm    = 1'b1;
        delta_alarm   = 1'b0;
        stale_alarm   = 1'b0;
        sensor_alarm  = 1'b1;

        // enable + over + sensor = 0x91
        axi_read_check(ADDR_STATUS, 32'h0000_0091, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("TEST 6: BVALID Backpressure");
        $display("============================================================");

        s_axil_bready = 1'b0;

        @(negedge clk);
        s_axil_awaddr  = ADDR_MAX_DELTA;
        s_axil_awvalid = 1'b1;
        s_axil_wdata   = 32'd888;
        s_axil_wstrb   = 4'b1111;
        s_axil_wvalid  = 1'b1;

        @(posedge clk);
        #1;

        check1("BVALID asserted", s_axil_bvalid, 1'b1);
        check2("BRESP is OKAY", s_axil_bresp, AXI_RESP_OKAY);
        check32("Write committed", {20'd0, max_delta}, 32'd888);

        @(negedge clk);
        s_axil_awvalid = 1'b0;
        s_axil_wvalid  = 1'b0;

        repeat (3) begin
            @(posedge clk);
            #1;
            check1("BVALID held", s_axil_bvalid, 1'b1);
            check2("BRESP held", s_axil_bresp, AXI_RESP_OKAY);
            check1("AWREADY blocked", s_axil_awready, 1'b0);
            check1("WREADY blocked", s_axil_wready, 1'b0);
        end

        @(negedge clk);
        s_axil_bready = 1'b1;

        @(posedge clk);
        #1;
        check1("BVALID clears after handshake", s_axil_bvalid, 1'b0);

        $display("\n============================================================");
        $display("TEST 7: RVALID/RDATA Backpressure");
        $display("============================================================");

        current_adc = 12'hABC;
        s_axil_rready = 1'b0;

        @(negedge clk);
        s_axil_araddr  = ADDR_CURRENT_ADC;
        s_axil_arvalid = 1'b1;

        @(posedge clk);
        #1;

        check1("RVALID asserted", s_axil_rvalid, 1'b1);
        check2("RRESP is OKAY", s_axil_rresp, AXI_RESP_OKAY);
        check32("RDATA captured", s_axil_rdata, 32'h0000_0ABC);

        @(negedge clk);
        s_axil_arvalid = 1'b0;
        current_adc = 12'h123;

        repeat (3) begin
            @(posedge clk);
            #1;
            check1("RVALID held", s_axil_rvalid, 1'b1);
            check2("RRESP held", s_axil_rresp, AXI_RESP_OKAY);
            check32("RDATA held despite source change",
                    s_axil_rdata, 32'h0000_0ABC);
            check1("ARREADY blocked", s_axil_arready, 1'b0);
        end

        @(negedge clk);
        s_axil_rready = 1'b1;

        @(posedge clk);
        #1;
        check1("RVALID clears after handshake", s_axil_rvalid, 1'b0);

        $display("\n============================================================");
        $display("TEST 8: SLVERR and Read-only Protection");
        $display("============================================================");

        axi_read_check(ADDR_MAX_DELTA, 32'd888, AXI_RESP_OKAY);

        axi_write_same(7'h2C, 32'hFFFF_FFFF, 4'b1111,
                       AXI_RESP_SLVERR);
        check32("Unsupported write preserves max_delta",
                {20'd0, max_delta}, 32'd888);

        axi_write_same(7'h05, 32'h1234_5678, 4'b1111,
                       AXI_RESP_SLVERR);
        check32("Unaligned write preserves low",
                {20'd0, low_threshold}, 32'h0000_0BAA);
        check32("Unaligned write preserves high",
                {20'd0, high_threshold}, 32'h0000_0ACC);

        axi_write_same(ADDR_STATUS, 32'hFFFF_FFFF, 4'b1111,
                       AXI_RESP_SLVERR);
        check1("RO STATUS write preserves enable", enable, 1'b1);

        axi_write_same(ADDR_IP_VERSION, 32'h0000_0000, 4'b1111,
                       AXI_RESP_SLVERR);
        axi_read_check(ADDR_IP_VERSION, 32'h0001_0000, AXI_RESP_OKAY);

        axi_read_check(7'h2C, 32'h0000_0000, AXI_RESP_SLVERR);
        axi_read_check(7'h15, 32'h0000_0000, AXI_RESP_SLVERR);

        $display("\n============================================================");
        $display("TEST 9: Asynchronous Reset During Operation");
        $display("============================================================");

        check1("Pre-reset enable", enable, 1'b1);
        check32("Pre-reset max_delta", {20'd0, max_delta}, 32'd888);
        check32("Pre-reset stale_limit",
                stale_limit_cycles, 32'hAA34_BB78);

        @(negedge clk);
        #2;
        reset_p = 1'b1;
        #1;

        check1 ("Async reset enable", enable, 1'b0);
        check1 ("Async reset clear_pulse", clear_pulse, 1'b0);
        check32("Async reset low_threshold",
                {20'd0, low_threshold}, 32'd410);
        check32("Async reset high_threshold",
                {20'd0, high_threshold}, 32'd3685);
        check32("Async reset max_delta",
                {20'd0, max_delta}, 32'd512);
        check32("Async reset stale_limit",
                stale_limit_cycles, 32'd50_000_000);
        check1 ("Async reset BVALID", s_axil_bvalid, 1'b0);
        check1 ("Async reset RVALID", s_axil_rvalid, 1'b0);

        #4;
        reset_p = 1'b0;
        @(posedge clk);
        #1;

        axi_read_check(ADDR_CONTROL,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD,    32'h0E65_019A, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,    32'h0000_0200, AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT,  32'h02FA_F080, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'h0000_0123, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0EEE_0111, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("Checks executed : %0d", check_count);
        $display("Failures        : %0d", failure_count);

        if (failure_count == 0) begin
            $display("RESULT          : ALL TESTS PASSED");
            $display("SENSOR_GUARD_AXI_LITE_REGS TEST PASS");
        end
        else begin
            $display("RESULT          : TEST FAILED");
        end

        $display("============================================================\n");

        #20;
        $finish;
    end

endmodule
