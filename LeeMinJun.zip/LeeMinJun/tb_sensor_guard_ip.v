`timescale 1ns / 1ps

//////////////////////////////////////////////////////////////////////////////////
// tb_sensor_guard_ip
//
// Self-checking integration testbench for sensor_guard_ip
//
// Verilog-2005
// DUT overrides:
//   STALE_LIMIT_DEFAULT = 5
//   COUNTER_WIDTH       = 4
//////////////////////////////////////////////////////////////////////////////////

module tb_sensor_guard_ip;

    localparam [1:0] AXI_RESP_OKAY   = 2'b00;
    localparam [1:0] AXI_RESP_SLVERR = 2'b10;

    localparam [6:0] ADDR_CONTROL      = 7'h00;
    localparam [6:0] ADDR_THRESHOLD    = 7'h04;
    localparam [6:0] ADDR_MAX_DELTA    = 7'h08;
    localparam [6:0] ADDR_STALE_LIMIT  = 7'h0C;
    localparam [6:0] ADDR_CURRENT_ADC  = 7'h10;
    localparam [6:0] ADDR_MIN_MAX      = 7'h14;
    localparam [6:0] ADDR_STATUS       = 7'h18;
    localparam [6:0] ADDR_SAMPLE_COUNT = 7'h1C;
    localparam [6:0] ADDR_ALARM_COUNT  = 7'h20;
    localparam [6:0] ADDR_LAST_DELTA   = 7'h24;
    localparam [6:0] ADDR_IP_VERSION   = 7'h28;

    reg         clk;
    reg         reset_p;

    reg  [11:0] adc_raw;
    reg         adc_valid;

    wire [11:0] current_adc;
    wire        display_valid;
    wire        sensor_alarm;

    reg  [6:0]  s_axil_awaddr;
    reg         s_axil_awvalid;
    wire        s_axil_awready;

    reg  [31:0] s_axil_wdata;
    reg  [3:0]  s_axil_wstrb;
    reg         s_axil_wvalid;
    wire        s_axil_wready;

    wire [1:0]  s_axil_bresp;
    wire        s_axil_bvalid;
    reg         s_axil_bready;

    reg  [6:0]  s_axil_araddr;
    reg         s_axil_arvalid;
    wire        s_axil_arready;

    wire [31:0] s_axil_rdata;
    wire [1:0]  s_axil_rresp;
    wire        s_axil_rvalid;
    reg         s_axil_rready;

    integer check_count;
    integer failure_count;
    integer index;

    sensor_guard_ip #(
        .LOW_THRESHOLD_DEFAULT  (410),
        .HIGH_THRESHOLD_DEFAULT (3685),
        .MAX_DELTA_DEFAULT      (512),
        .STALE_LIMIT_DEFAULT    (5),
        .COUNTER_WIDTH          (4)
    ) dut (
        .clk                (clk),
        .reset_p            (reset_p),

        .adc_raw            (adc_raw),
        .adc_valid          (adc_valid),

        .current_adc        (current_adc),
        .display_valid      (display_valid),
        .sensor_alarm       (sensor_alarm),

        .s_axil_awaddr      (s_axil_awaddr),
        .s_axil_awvalid     (s_axil_awvalid),
        .s_axil_awready     (s_axil_awready),

        .s_axil_wdata       (s_axil_wdata),
        .s_axil_wstrb       (s_axil_wstrb),
        .s_axil_wvalid      (s_axil_wvalid),
        .s_axil_wready      (s_axil_wready),

        .s_axil_bresp       (s_axil_bresp),
        .s_axil_bvalid      (s_axil_bvalid),
        .s_axil_bready      (s_axil_bready),

        .s_axil_araddr      (s_axil_araddr),
        .s_axil_arvalid     (s_axil_arvalid),
        .s_axil_arready     (s_axil_arready),

        .s_axil_rdata       (s_axil_rdata),
        .s_axil_rresp       (s_axil_rresp),
        .s_axil_rvalid      (s_axil_rvalid),
        .s_axil_rready      (s_axil_rready)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        #200000;
        $display("[TIMEOUT] Testbench did not finish.");
        $finish;
    end

    task check1;
        input [8*104-1:0] label_text;
        input actual_value;
        input expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=%b expected=%b @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=%b",
                         label_text, actual_value);
            end
        end
    endtask

    task check2;
        input [8*104-1:0] label_text;
        input [1:0] actual_value;
        input [1:0] expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=%b expected=%b @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=%b",
                         label_text, actual_value);
            end
        end
    endtask

    task check12;
        input [8*104-1:0] label_text;
        input [11:0] actual_value;
        input [11:0] expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=%0d(0x%03h) expected=%0d(0x%03h) @ %0t",
                         label_text,
                         actual_value, actual_value,
                         expected_value, expected_value,
                         $time);
            end
            else begin
                $display("[PASS] %0s | value=%0d(0x%03h)",
                         label_text, actual_value, actual_value);
            end
        end
    endtask

    task check32;
        input [8*104-1:0] label_text;
        input [31:0] actual_value;
        input [31:0] expected_value;
        begin
            check_count = check_count + 1;

            if (actual_value !== expected_value) begin
                failure_count = failure_count + 1;
                $display("[FAIL] %0s | actual=0x%08h expected=0x%08h @ %0t",
                         label_text, actual_value, expected_value, $time);
            end
            else begin
                $display("[PASS] %0s | value=0x%08h",
                         label_text, actual_value);
            end
        end
    endtask

    task axi_write_same;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input [1:0]  expected_response;
        reg aw_done;
        reg w_done;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;
            s_axil_wdata   = data_value;
            s_axil_wstrb   = strobe_value;
            s_axil_wvalid  = 1'b1;

            aw_done = 1'b0;
            w_done  = 1'b0;

            while (!(aw_done && w_done)) begin
                @(posedge clk);

                if (s_axil_awvalid && s_axil_awready)
                    aw_done = 1'b1;

                if (s_axil_wvalid && s_axil_wready)
                    w_done = 1'b1;

                @(negedge clk);

                if (aw_done)
                    s_axil_awvalid = 1'b0;

                if (w_done)
                    s_axil_wvalid = 1'b0;
            end

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("AXI Write BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("AXI Write BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_write_aw_first;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input integer delay_cycles;
        input [1:0]  expected_response;
        integer delay_index;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;

            while (!s_axil_awready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_awvalid = 1'b0;

            check1("AW-first no early BVALID", s_axil_bvalid, 1'b0);

            for (delay_index = 0;
                 delay_index < delay_cycles;
                 delay_index = delay_index + 1) begin
                @(posedge clk);
                #1;
                check1("AW-first waits for W", s_axil_bvalid, 1'b0);
            end

            @(negedge clk);
            s_axil_wdata   = data_value;
            s_axil_wstrb   = strobe_value;
            s_axil_wvalid  = 1'b1;

            while (!s_axil_wready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_wvalid = 1'b0;

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("AW-first BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("AW-first BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_write_w_first;
        input [6:0]  address;
        input [31:0] data_value;
        input [3:0]  strobe_value;
        input integer delay_cycles;
        input [1:0]  expected_response;
        integer delay_index;
        begin
            s_axil_bready = 1'b1;

            @(negedge clk);
            s_axil_wdata   = data_value;
            s_axil_wstrb   = strobe_value;
            s_axil_wvalid  = 1'b1;

            while (!s_axil_wready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_wvalid = 1'b0;

            check1("W-first no early BVALID", s_axil_bvalid, 1'b0);

            for (delay_index = 0;
                 delay_index < delay_cycles;
                 delay_index = delay_index + 1) begin
                @(posedge clk);
                #1;
                check1("W-first waits for AW", s_axil_bvalid, 1'b0);
            end

            @(negedge clk);
            s_axil_awaddr  = address;
            s_axil_awvalid = 1'b1;

            while (!s_axil_awready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_awvalid = 1'b0;

            while (!s_axil_bvalid)
                @(negedge clk);

            check2("W-first BRESP", s_axil_bresp, expected_response);

            @(posedge clk);
            #1;
            check1("W-first BVALID released", s_axil_bvalid, 1'b0);
        end
    endtask

    task axi_read_check;
        input [6:0]  address;
        input [31:0] expected_data;
        input [1:0]  expected_response;
        begin
            s_axil_rready = 1'b1;

            @(negedge clk);
            s_axil_araddr  = address;
            s_axil_arvalid = 1'b1;

            while (!s_axil_arready)
                @(negedge clk);

            @(posedge clk);
            @(negedge clk);
            s_axil_arvalid = 1'b0;

            while (!s_axil_rvalid)
                @(negedge clk);

            check2("AXI Read RRESP", s_axil_rresp, expected_response);
            check32("AXI Read RDATA", s_axil_rdata, expected_data);

            @(posedge clk);
            #1;
            check1("AXI Read RVALID released", s_axil_rvalid, 1'b0);
        end
    endtask

    task send_sample;
        input [11:0] sample_value;
        begin
            @(negedge clk);
            adc_raw   = sample_value;
            adc_valid = 1'b1;

            @(posedge clk);
            #1;

            @(negedge clk);
            adc_valid = 1'b0;
        end
    endtask

    task wait_no_sample_clocks;
        input integer clock_count;
        integer wait_index;
        begin
            adc_valid = 1'b0;

            for (wait_index = 0;
                 wait_index < clock_count;
                 wait_index = wait_index + 1) begin
                @(posedge clk);
                #1;
            end
        end
    endtask

    task clear_with_simultaneous_sample;
        input [11:0] sample_value;
        begin
            fork
                begin
                    axi_write_same(
                        ADDR_CONTROL,
                        32'h0000_0003,
                        4'b0001,
                        AXI_RESP_OKAY
                    );
                end

                begin
                    wait (dut.guard_clear_pulse === 1'b1);
                    @(negedge clk);
                    adc_raw   = sample_value;
                    adc_valid = 1'b1;

                    @(posedge clk);
                    #1;

                    @(negedge clk);
                    adc_valid = 1'b0;
                end
            join
        end
    endtask

    initial begin
        check_count   = 0;
        failure_count = 0;

        reset_p = 1'b0;

        adc_raw   = 12'd0;
        adc_valid = 1'b0;

        s_axil_awaddr  = 7'd0;
        s_axil_awvalid = 1'b0;
        s_axil_wdata   = 32'd0;
        s_axil_wstrb   = 4'd0;
        s_axil_wvalid  = 1'b0;
        s_axil_bready  = 1'b1;

        s_axil_araddr  = 7'd0;
        s_axil_arvalid = 1'b0;
        s_axil_rready  = 1'b1;

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 1: Asynchronous Reset and Reset Defaults");
        $display("============================================================");

        #2;
        reset_p = 1'b1;
        #1;

        check12("Reset current_adc", current_adc, 12'd0);
        check1 ("Reset display_valid", display_valid, 1'b0);
        check1 ("Reset sensor_alarm", sensor_alarm, 1'b0);
        check1 ("Reset BVALID", s_axil_bvalid, 1'b0);
        check1 ("Reset RVALID", s_axil_rvalid, 1'b0);

        repeat (2) @(posedge clk);
        @(negedge clk);
        reset_p = 1'b0;

        #1;
        check1("AWREADY after reset", s_axil_awready, 1'b1);
        check1("WREADY after reset", s_axil_wready, 1'b1);
        check1("ARREADY after reset", s_axil_arready, 1'b1);

        axi_read_check(ADDR_CONTROL,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD,    32'h0E65_019A, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,    32'h0000_0200, AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT,  32'h0000_0005, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,       32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 2: Disabled Input Ignore and AXI Configuration");
        $display("============================================================");

        send_sample(12'd1234);

        check12("Disabled sample ignored current_adc", current_adc, 12'd0);
        check1 ("Disabled sample keeps display invalid", display_valid, 1'b0);
        check1 ("Disabled sample keeps alarm low", sensor_alarm, 1'b0);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd0, AXI_RESP_OKAY);

        // General tests use a large Stale limit.
        axi_write_aw_first(
            ADDR_THRESHOLD,
            32'h0DAC_01F4,
            4'b1111,
            2,
            AXI_RESP_OKAY
        );

        axi_write_w_first(
            ADDR_MAX_DELTA,
            32'd200,
            4'b1111,
            2,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd1000,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0001,
            4'b0001,
            AXI_RESP_OKAY
        );

        axi_read_check(ADDR_THRESHOLD,   32'h0DAC_01F4, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,   32'd200,       AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT, 32'd1000,      AXI_RESP_OKAY);
        axi_read_check(ADDR_CONTROL,     32'h0000_0001, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,      32'h0000_0001, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 3: First Sample, Normal Sample and Statistics");
        $display("============================================================");

        send_sample(12'd1000);

        check12("First sample current_adc", current_adc, 12'd1000);
        check1 ("First sample display_valid", display_valid, 1'b1);
        check1 ("First sample sensor_alarm", sensor_alarm, 1'b0);

        axi_read_check(ADDR_STATUS,       32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'd1000, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h03E8_03E8, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd1, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd0, AXI_RESP_OKAY);

        send_sample(12'd1100);

        axi_read_check(ADDR_CURRENT_ADC,  32'd1100, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h044C_03E8, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'd100, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd2, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd0, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 4: Threshold and Delta Boundaries");
        $display("============================================================");

        // Under + Delta together: one alarm_count increment.
        send_sample(12'd300);

        check1("Under+Delta keeps display_valid", display_valid, 1'b1);
        check1("Under+Delta sets sensor_alarm", sensor_alarm, 1'b1);
        axi_read_check(ADDR_STATUS,       32'h0000_00AF, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd1, AXI_RESP_OKAY);

        // Low threshold and exact max_delta are normal.
        send_sample(12'd500);

        check1("Low and Delta boundary clear alarm", sensor_alarm, 1'b0);
        axi_read_check(ADDR_STATUS,      32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,  32'd200, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd1, AXI_RESP_OKAY);

        // Temporarily disable Delta to isolate High/Over checks.
        axi_write_same(
            ADDR_MAX_DELTA,
            32'd4095,
            4'b1111,
            AXI_RESP_OKAY
        );

        send_sample(12'd3500);
        check1("High threshold boundary normal", sensor_alarm, 1'b0);
        axi_read_check(ADDR_STATUS, 32'h0000_0007, AXI_RESP_OKAY);

        send_sample(12'd3600);
        check1("Over sample keeps display_valid", display_valid, 1'b1);
        check1("Over sample sets sensor_alarm", sensor_alarm, 1'b1);
        axi_read_check(ADDR_STATUS,      32'h0000_0097, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd2, AXI_RESP_OKAY);

        send_sample(12'd3500);
        check1("Normal sample clears Over", sensor_alarm, 1'b0);

        // Clear statistics but preserve settings, then test Delta boundary.
        axi_write_same(
            ADDR_MAX_DELTA,
            32'd200,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);
        send_sample(12'd1201);

        check1("Delta greater than limit alarms", sensor_alarm, 1'b1);
        axi_read_check(ADDR_STATUS,      32'h0000_00A7, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,  32'd201, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd1, AXI_RESP_OKAY);

        send_sample(12'd1401);

        check1("Exact Delta boundary normal", sensor_alarm, 1'b0);
        axi_read_check(ADDR_STATUS,      32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,  32'd200, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd1, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 5: Exact Stale Boundary and Recovery");
        $display("============================================================");

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd3,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);

        wait_no_sample_clocks(1);
        check1("Stale idle 1 remains low", sensor_alarm, 1'b0);
        check1("Stale idle 1 display valid", display_valid, 1'b1);

        wait_no_sample_clocks(1);
        check1("Stale idle 2 remains low", sensor_alarm, 1'b0);
        check1("Stale idle 2 display valid", display_valid, 1'b1);

        wait_no_sample_clocks(1);
        check1("Stale idle 3 alarms", sensor_alarm, 1'b1);
        check1("Stale idle 3 invalidates display", display_valid, 1'b0);

        axi_read_check(ADDR_STATUS,       32'h0000_00C3, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd1, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd1, AXI_RESP_OKAY);

        wait_no_sample_clocks(4);
        axi_read_check(ADDR_ALARM_COUNT, 32'd1, AXI_RESP_OKAY);

        send_sample(12'd1001);

        check1("New sample clears Stale", sensor_alarm, 1'b0);
        check1("New sample restores display", display_valid, 1'b1);

        // Prevent AXI traffic from causing another short Stale event.
        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd1000,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_read_check(ADDR_STATUS,      32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd1, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 6: Sample Priority on Planned Stale Clock");
        $display("============================================================");

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd3,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);
        wait_no_sample_clocks(2);

        // This sample arrives on the clock that otherwise would assert Stale.
        send_sample(12'd1001);

        check1("Planned Stale clock sample prevents alarm",
               sensor_alarm, 1'b0);
        check1("Planned Stale clock sample keeps display valid",
               display_valid, 1'b1);

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd1000,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_read_check(ADDR_STATUS,      32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd0, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 7: stale_limit=0 Disable");
        $display("============================================================");

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd0,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);
        wait_no_sample_clocks(12);

        check1("stale_limit zero keeps alarm low", sensor_alarm, 1'b0);
        check1("stale_limit zero keeps display valid", display_valid, 1'b1);
        axi_read_check(ADDR_STATUS,      32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT, 32'd0, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 8: Disable Preserve and Re-enable Baseline");
        $display("============================================================");

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd1000,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);
        send_sample(12'd1200);

        axi_read_check(ADDR_CURRENT_ADC,  32'd1200, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h04B0_03E8, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'd200, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd2, AXI_RESP_OKAY);

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0000,
            4'b0001,
            AXI_RESP_OKAY
        );

        check12("Disable preserves current_adc", current_adc, 12'd1200);
        check1 ("Disable clears display_valid", display_valid, 1'b0);
        check1 ("Disable clears sensor_alarm", sensor_alarm, 1'b0);
        axi_read_check(ADDR_STATUS, 32'h0000_0000, AXI_RESP_OKAY);

        send_sample(12'd100);

        check12("Disabled adc_valid ignored", current_adc, 12'd1200);
        axi_read_check(ADDR_MIN_MAX,      32'h04B0_03E8, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd2, AXI_RESP_OKAY);

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0001,
            4'b0001,
            AXI_RESP_OKAY
        );

        axi_read_check(ADDR_STATUS, 32'h0000_0001, AXI_RESP_OKAY);

        send_sample(12'd3000);

        check1("Re-enable first sample has no alarm", sensor_alarm, 1'b0);
        axi_read_check(ADDR_STATUS,       32'h0000_0007, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0BB8_03E8, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd3, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 9: Clear Priority and Register Preservation");
        $display("============================================================");

        clear_with_simultaneous_sample(12'd2222);

        check12("Clear ignores simultaneous sample", current_adc, 12'd0);
        check1 ("Clear resets display_valid", display_valid, 1'b0);
        check1 ("Clear resets sensor_alarm", sensor_alarm, 1'b0);

        axi_read_check(ADDR_CONTROL,      32'h0000_0001, AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD,    32'h0DAC_01F4, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,    32'd200, AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT,  32'd1000, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,       32'h0000_0001, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'd0, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 10: Counter Saturation");
        $display("============================================================");

        // Disable all sample alarms, then overfill sample_count.
        axi_write_same(
            ADDR_THRESHOLD,
            32'h0FFF_0000,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_MAX_DELTA,
            32'd4095,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_STALE_LIMIT,
            32'd0,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        for (index = 0; index < 20; index = index + 1)
            send_sample(12'd1000 + index);

        axi_read_check(ADDR_SAMPLE_COUNT, 32'd15, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd0,  AXI_RESP_OKAY);

        // Every sample is Under. Both counters must saturate at 15.
        axi_write_same(
            ADDR_THRESHOLD,
            32'h0FFF_01F4,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0003,
            4'b0001,
            AXI_RESP_OKAY
        );

        for (index = 0; index < 20; index = index + 1)
            send_sample(12'd100);

        axi_read_check(ADDR_SAMPLE_COUNT, 32'd15, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'd15, AXI_RESP_OKAY);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 11: WSTRB and AXI Backpressure");
        $display("============================================================");

        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0000,
            4'b0001,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_THRESHOLD,
            32'h0DAC_012C,
            4'b1111,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_THRESHOLD,
            32'h0000_00AA,
            4'b0001,
            AXI_RESP_OKAY
        );

        axi_write_same(
            ADDR_THRESHOLD,
            32'h0000_0B00,
            4'b0010,
            AXI_RESP_OKAY
        );

        axi_read_check(ADDR_THRESHOLD, 32'h0DAC_0BAA, AXI_RESP_OKAY);

        // BVALID backpressure
        s_axil_bready = 1'b0;

        @(negedge clk);
        s_axil_awaddr  = ADDR_MAX_DELTA;
        s_axil_awvalid = 1'b1;
        s_axil_wdata   = 32'd888;
        s_axil_wstrb   = 4'b1111;
        s_axil_wvalid  = 1'b1;

        @(posedge clk);
        #1;

        check1("BVALID asserted under backpressure",
               s_axil_bvalid, 1'b1);
        check2("BRESP stable under backpressure",
               s_axil_bresp, AXI_RESP_OKAY);

        @(negedge clk);
        s_axil_awvalid = 1'b0;
        s_axil_wvalid  = 1'b0;

        repeat (3) begin
            @(posedge clk);
            #1;
            check1("BVALID held while BREADY low",
                   s_axil_bvalid, 1'b1);
            check1("AWREADY blocked while response pending",
                   s_axil_awready, 1'b0);
            check1("WREADY blocked while response pending",
                   s_axil_wready, 1'b0);
        end

        @(negedge clk);
        s_axil_bready = 1'b1;

        @(posedge clk);
        #1;
        check1("BVALID clears after response handshake",
               s_axil_bvalid, 1'b0);

        // RVALID/RDATA backpressure
        s_axil_rready = 1'b0;

        @(negedge clk);
        s_axil_araddr  = ADDR_IP_VERSION;
        s_axil_arvalid = 1'b1;

        @(posedge clk);
        #1;

        check1("RVALID asserted under backpressure",
               s_axil_rvalid, 1'b1);
        check2("RRESP stable under backpressure",
               s_axil_rresp, AXI_RESP_OKAY);
        check32("RDATA captured under backpressure",
                s_axil_rdata, 32'h0001_0000);

        @(negedge clk);
        s_axil_arvalid = 1'b0;

        repeat (3) begin
            @(posedge clk);
            #1;
            check1("RVALID held while RREADY low",
                   s_axil_rvalid, 1'b1);
            check32("RDATA held while RREADY low",
                    s_axil_rdata, 32'h0001_0000);
            check1("ARREADY blocked while response pending",
                   s_axil_arready, 1'b0);
        end

        @(negedge clk);
        s_axil_rready = 1'b1;

        @(posedge clk);
        #1;
        check1("RVALID clears after response handshake",
               s_axil_rvalid, 1'b0);

        // ---------------------------------------------------------------------
        $display("\n============================================================");
        $display("TEST 12: Invalid Access and Runtime Asynchronous Reset");
        $display("============================================================");

        axi_write_same(
            ADDR_STATUS,
            32'hFFFF_FFFF,
            4'b1111,
            AXI_RESP_SLVERR
        );

        axi_write_same(
            ADDR_IP_VERSION,
            32'h0000_0000,
            4'b1111,
            AXI_RESP_SLVERR
        );

        axi_write_same(
            7'h05,
            32'h1234_5678,
            4'b1111,
            AXI_RESP_SLVERR
        );

        axi_write_same(
            7'h2C,
            32'h1234_5678,
            4'b1111,
            AXI_RESP_SLVERR
        );

        axi_read_check(7'h15, 32'd0, AXI_RESP_SLVERR);
        axi_read_check(7'h2C, 32'd0, AXI_RESP_SLVERR);
        axi_read_check(ADDR_IP_VERSION, 32'h0001_0000, AXI_RESP_OKAY);

        // Create non-default state before runtime reset.
        axi_write_same(
            ADDR_CONTROL,
            32'h0000_0001,
            4'b0001,
            AXI_RESP_OKAY
        );

        send_sample(12'd1000);

        @(negedge clk);
        #2;
        reset_p = 1'b1;
        #1;

        check12("Runtime reset current_adc", current_adc, 12'd0);
        check1 ("Runtime reset display_valid", display_valid, 1'b0);
        check1 ("Runtime reset sensor_alarm", sensor_alarm, 1'b0);
        check1 ("Runtime reset BVALID", s_axil_bvalid, 1'b0);
        check1 ("Runtime reset RVALID", s_axil_rvalid, 1'b0);

        #4;
        reset_p = 1'b0;
        @(posedge clk);
        #1;

        axi_read_check(ADDR_CONTROL,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_THRESHOLD,    32'h0E65_019A, AXI_RESP_OKAY);
        axi_read_check(ADDR_MAX_DELTA,    32'h0000_0200, AXI_RESP_OKAY);
        axi_read_check(ADDR_STALE_LIMIT,  32'h0000_0005, AXI_RESP_OKAY);
        axi_read_check(ADDR_CURRENT_ADC,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_MIN_MAX,      32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_STATUS,       32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_SAMPLE_COUNT, 32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_ALARM_COUNT,  32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_LAST_DELTA,   32'h0000_0000, AXI_RESP_OKAY);
        axi_read_check(ADDR_IP_VERSION,   32'h0001_0000, AXI_RESP_OKAY);

        $display("\n============================================================");
        $display("Checks executed : %0d", check_count);
        $display("Failures        : %0d", failure_count);

        if (failure_count == 0) begin
            $display("RESULT          : ALL TESTS PASSED");
            $display("SENSOR_GUARD_IP TEST PASS");
        end
        else begin
            $display("RESULT          : TEST FAILED");
        end

        $display("============================================================\n");

        #20;
        $finish;
    end

endmodule
